package com.apress.myfaces;

import com.sun.facelets.tag.MetaRule;
import com.sun.facelets.tag.MetaRuleset;
import com.sun.facelets.tag.MethodRule;
import com.sun.facelets.tag.TagAttribute;
import com.sun.facelets.tag.jsf.ComponentConfig;
import com.sun.facelets.tag.jsf.html.HtmlComponentHandler;

import java.util.List;

public class InputSuggestAjaxComponentHandler extends HtmlComponentHandler
{
    private TagAttribute maxSuggestedItems;

   public InputSuggestAjaxComponentHandler(ComponentConfig tagConfig) {
      super(tagConfig);

       maxSuggestedItems = getAttribute("maxSuggestedItems");
   }

   protected MetaRuleset createMetaRuleset(Class type)
    {
        MetaRuleset metaRuleset = super.createMetaRuleset(type);

        Class[] paramList = maxSuggestedItems != null ?
            new Class[] {String.class, Integer.class} : new Class[]{String.class};
        MetaRule metaRule = new MethodRule("suggestedItemsMethod", List.class, paramList);

        metaRuleset.addRule(metaRule);

        return metaRuleset;
    }
}
