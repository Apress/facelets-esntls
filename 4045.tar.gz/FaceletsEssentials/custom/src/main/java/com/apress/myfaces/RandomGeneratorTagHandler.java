package com.apress.myfaces;

import com.sun.facelets.FaceletContext;
import com.sun.facelets.FaceletException;
import com.sun.facelets.tag.TagAttribute;
import com.sun.facelets.tag.TagConfig;
import com.sun.facelets.tag.TagHandler;
import com.sun.facelets.tag.jsf.ComponentSupport;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import java.io.IOException;
import java.util.Random;

public class RandomGeneratorTagHandler extends TagHandler
{
    private TagAttribute min;
    private TagAttribute max;
    private TagAttribute var;

    public RandomGeneratorTagHandler(TagConfig tagConfig)
    {
        super(tagConfig);

        // min attribute
        this.min = getAttribute("min");

        // max attribute
        this.max = getAttribute("max");

        // var attribute
        this.var = getRequiredAttribute("var");
    }

    public void apply(FaceletContext faceletContext, UIComponent parent) throws IOException, FacesException, FaceletException, ELException
    {
            int minValue = Integer.MIN_VALUE;
            if (this.min != null)
            {
                minValue = min.getInt(faceletContext);
            }

            int maxValue = Integer.MAX_VALUE;
            if (this.max != null)
            {
                maxValue = max.getInt(faceletContext);
            }

            int randomNum = new Random().nextInt(maxValue) + minValue;

            faceletContext.setAttribute(var.getValue(faceletContext), randomNum);

            this.nextHandler.apply(faceletContext, parent);
    }
}
