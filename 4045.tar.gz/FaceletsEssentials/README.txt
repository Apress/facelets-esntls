Apress - Facelets Essentials
----------------------------

This bundle contains the sources for the "Facelets Essentials" book, using a Maven (http://maven.apache.org) layout.

The sources are divided in three groups, corresponding to a folder:

creatingAnApp - Contains the sources for the first part of the book, where an application is created to introduce Facelets.
tagReferenceAndComposite - Examples for the Facelets tags and composite components.
custom - An example creating a custom component.

Jetty can be used to start the applications easily. To see the examples in action, the best way is:

- cd creatingAnApp
- mvn jetty:run

And then jetty will start and the application can be tested by navigating to http://localhost:8080/creatingAnApp in
your favourite browser. The same can be done for the other web applications.
Additionally, it is possible to use JSF 1.2 for the examples, by passing the "jsf=1.2" variable to the mvn command:

mvn jetty:run -Djsf=1.2

As Maven is used, if you want to create a war file containing the test application, for instance to deploy it in tomcat,
just execute:

mvn package

The sources for the examples can be found in the "src" folder for each application.

Enjoy!