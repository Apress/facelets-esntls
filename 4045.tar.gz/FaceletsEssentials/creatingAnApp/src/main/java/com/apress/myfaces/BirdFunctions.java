package com.apress.myfaces;

public class BirdFunctions {
    public static String canSpeak(String birdName) {
        if (birdName.equals("parrot")) {
            return "YES";
        }
        return "If you try hard enough, who knows!";
    }
}
