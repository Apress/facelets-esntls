package com.apress.myfaces;

public class Bird
{
    private String name;
    private String order;
    private String family;

    public Bird()
    {
    }

    public Bird(String name, String order, String family)
    {
        this.name = name;
        this.order = order;
        this.family = family;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getOrder()
    {
        return order;
    }

    public void setOrder(String order)
    {
        this.order = order;
    }

    public String getFamily()
    {
        return family;
    }

    public void setFamily(String family)
    {
        this.family = family;
    }
}
