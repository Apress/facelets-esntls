package com.apress.myfaces;

import javax.faces.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * TODO comment this
 *
 * @author Bruno Aranda (baranda@ebi.ac.uk)
 * @version $Id$
 */
public class BirdDirectoryBean
{
    private List<Bird> birds;
    private List<Bird> allBirds;
    private String favouriteName;

    public BirdDirectoryBean()
    {

        allBirds = new ArrayList<Bird>(29);
        allBirds.add(new Bird("Parrot", "Psittaciformes", "Psittacidae"));
        allBirds.add(new Bird("Eagle", "Falconiformes", "Accipitridae"));
        allBirds.add(new Bird("Loon", "Gaviiformes", "Gaviidae"));
        allBirds.add(new Bird("Grebe", "Podicipediformes", "Podicipedidae"));
        allBirds.add(new Bird("Albatross", "Procellariiformes", "Diomedeidae"));
        allBirds.add(new Bird("Petrel", "Procellariiformes", "Procellariidae"));
        allBirds.add(new Bird("Pelican", "Pelecaniformes", "Pelecanidae"));
        allBirds.add(new Bird("Cormorant", "Pelecaniformes", "Phalacrocoracidae"));
        allBirds.add(new Bird("Ibis", "Ciconiiformes", "Threskiornithidae"));
        allBirds.add(new Bird("Flamingo", "Phoenicopteriformes", "Phoenicopteridae"));
        allBirds.add(new Bird("Waterfowl", "Anseriformes", "Anatidae"));
        allBirds.add(new Bird("Vulture", "Falconiformes", "Cathartidae"));
        allBirds.add(new Bird("Falcon", "Falconiformes", "Falconidae"));
        allBirds.add(new Bird("Curassow", "Galliformes", "Cracidae"));
        allBirds.add(new Bird("Quail", "Galliformes", "Odontophoridae"));
        allBirds.add(new Bird("Pheasants", "Galliformes", "Phasianidae"));
        allBirds.add(new Bird("Rail", "Gruiformes", "Rallidae"));
        allBirds.add(new Bird("Limpkin", "Gruiformes", "Aramidae"));
        allBirds.add(new Bird("Crane", "Gruiformes", "Gruidae"));
        allBirds.add(new Bird("Pigeon", "Columbiformes", "Columbidae"));
        allBirds.add(new Bird("Cuckoo", "Cuculiformes", "Cuculidae"));
        allBirds.add(new Bird("Goatsucker", "Caprimulgiformes", "Caprimulgidae"));
        allBirds.add(new Bird("Hummingbird", "Apodiformes", "Trochilidae"));
        allBirds.add(new Bird("Kingfisher", "Coraciiformes", "Alcedinidae"));
        allBirds.add(new Bird("Creeper", "Passeriformes", "Certhiidae"));
        allBirds.add(new Bird("Mockingbirds", "Passeriformes", "Mimidae"));
        allBirds.add(new Bird("Bananaquit", "Passeriformes", "Coerebidae"));
        allBirds.add(new Bird("Finch", "Falconiformes", "Fringillidae"));
        allBirds.add(new Bird("Sparrow", "Falconiformes", "Emberizidae"));
        

        birds = allBirds.subList(0,2);

        favouriteName = "Eagle";
    }

    public void printFavourite(ActionEvent evt) {
        System.out.println("Favourite bird: "+favouriteName);
    }

    public List<Bird> getBirds()
    {
        return birds;
    }

    public void setBirds(List<Bird> birds)
    {
        this.birds = birds;
    }

    public List<Bird> getAllBirds()
    {
        return allBirds;
    }

    public void setAllBirds(List<Bird> allBirds)
    {
        this.allBirds = allBirds;
    }

    public String getFavouriteName()
    {
        return favouriteName;
    }

    public void setFavouriteName(String favouriteName)
    {
        this.favouriteName = favouriteName;
    }
}
