package com.apress.myfaces;

import javax.faces.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

public class UserBean
{
    private boolean editMode;

    public UserBean()
    {
    }

    public boolean isEditMode()
    {
        return editMode;
    }

    public void setEditMode(boolean editMode)
    {
        this.editMode = editMode;
    }

    public void switchToEditMode(ActionEvent evt) {
        this.editMode = true;
    }

    public void switchToNormalMode(ActionEvent evt) {
        this.editMode = false;
    }
}